<?php
/**
 * Plugin Name: Power Reservations
 * Plugin URI: https://github.com/scottpowers/power-reservations
 * Description: Simple restaurant reservation management system for WordPress.
 * Version: 2.0.0
 * Author: Scott Powers
 * Author URI: https://scottpowers.dev
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: power-reservations
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Network: false
 */

// Prevent direct access to this file
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('PR_VERSION', '2.0.0');
define('PR_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include WordPress List Table class
if (!class_exists('WP_List_Table')) {
    require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}

/**
 * Power Reservations List Table Class
 */
class PR_Reservations_List_Table extends WP_List_Table {
    
    /**
     * Constructor
     */
    public function __construct() {
        parent::__construct(array(
            'singular' => 'reservation',
            'plural' => 'reservations',
            'ajax' => false
        ));
    }
    
    /**
     * Get columns
     */
    public function get_columns() {
        return array(
            'cb' => '<input type="checkbox" />',
            'reservation_id' => __('ID', 'power-reservations'),
            'name' => __('Name', 'power-reservations'),
            'email' => __('Email', 'power-reservations'),
            'phone' => __('Phone', 'power-reservations'),
            'reservation_date' => __('Date', 'power-reservations'),
            'reservation_time' => __('Time', 'power-reservations'),
            'party_size' => __('Party Size', 'power-reservations'),
            'status' => __('Status', 'power-reservations'),
            'created_at' => __('Created', 'power-reservations'),
            'actions' => __('Actions', 'power-reservations')
        );
    }
    
    /**
     * Get sortable columns
     */
    public function get_sortable_columns() {
        return array(
            'reservation_id' => array('reservation_id', false),
            'name' => array('name', false),
            'email' => array('email', false),
            'reservation_date' => array('reservation_date', true),
            'reservation_time' => array('reservation_time', false),
            'party_size' => array('party_size', false),
            'status' => array('status', false),
            'created_at' => array('created_at', true)
        );
    }
    
    /**
     * Get bulk actions
     */
    public function get_bulk_actions() {
        return array(
            'approve' => __('Approve', 'power-reservations'),
            'decline' => __('Decline', 'power-reservations'),
            'delete' => __('Delete', 'power-reservations')
        );
    }
    
    /**
     * Column default
     */
    public function column_default($item, $column_name) {
        switch ($column_name) {
            case 'reservation_id':
            case 'name':
            case 'email':
            case 'phone':
            case 'reservation_date':
            case 'reservation_time':
            case 'party_size':
            case 'created_at':
                return $item->$column_name;
            default:
                return print_r($item, true);
        }
    }
    
    /**
     * Column checkbox
     */
    public function column_cb($item) {
        return sprintf('<input type="checkbox" name="reservations[]" value="%s" />', $item->id);
    }
    
    /**
     * Column status
     */
    public function column_status($item) {
        $status_labels = array(
            'pending' => '<span class="status-pending">' . __('Pending', 'power-reservations') . '</span>',
            'approved' => '<span class="status-approved">' . __('Approved', 'power-reservations') . '</span>',
            'declined' => '<span class="status-declined">' . __('Declined', 'power-reservations') . '</span>',
            'cancelled' => '<span class="status-cancelled">' . __('Cancelled', 'power-reservations') . '</span>'
        );
        
        return isset($status_labels[$item->status]) ? $status_labels[$item->status] : $item->status;
    }
    
    /**
     * Column actions
     */
    public function column_actions($item) {
        $actions = array();
        
        if ($item->status === 'pending') {
            $actions['approve'] = sprintf(
                '<a href="?page=%s&action=approve&reservation=%s&_wpnonce=%s" class="button button-small button-primary">%s</a>',
                $_REQUEST['page'],
                $item->id,
                wp_create_nonce('approve_reservation_' . $item->id),
                __('Approve', 'power-reservations')
            );
            $actions['decline'] = sprintf(
                '<a href="?page=%s&action=decline&reservation=%s&_wpnonce=%s" class="button button-small">%s</a>',
                $_REQUEST['page'],
                $item->id,
                wp_create_nonce('decline_reservation_' . $item->id),
                __('Decline', 'power-reservations')
            );
        }
        
        $actions['edit'] = sprintf(
            '<a href="?page=%s&action=edit&reservation=%s" class="button button-small">%s</a>',
            $_REQUEST['page'],
            $item->id,
            __('Edit', 'power-reservations')
        );
        
        $actions['delete'] = sprintf(
            '<a href="?page=%s&action=delete&reservation=%s&_wpnonce=%s" class="button button-small" onclick="return confirm(\'%s\')">%s</a>',
            $_REQUEST['page'],
            $item->id,
            wp_create_nonce('delete_reservation_' . $item->id),
            __('Are you sure you want to delete this reservation?', 'power-reservations'),
            __('Delete', 'power-reservations')
        );
        
        return implode(' ', $actions);
    }
    
    /**
     * Prepare items
     */
    public function prepare_items() {
        global $wpdb;
        
        $per_page = 20;
        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();
        
        $this->_column_headers = array($columns, $hidden, $sortable);
        
        // Handle bulk actions
        $this->process_bulk_action();
        
        // Get data
        $table_name = $wpdb->prefix . 'pr_reservations';
        
        // Build query
        $where = '1=1';
        $where_args = array();
        
        // Search
        if (!empty($_REQUEST['s'])) {
            $search = '%' . $wpdb->esc_like($_REQUEST['s']) . '%';
            $where .= " AND (name LIKE %s OR email LIKE %s OR reservation_id LIKE %s)";
            $where_args = array_merge($where_args, array($search, $search, $search));
        }
        
        // Status filter
        if (!empty($_REQUEST['status']) && $_REQUEST['status'] !== 'all') {
            $where .= " AND status = %s";
            $where_args[] = $_REQUEST['status'];
        }
        
        // Date filter
        if (!empty($_REQUEST['date_from'])) {
            $where .= " AND reservation_date >= %s";
            $where_args[] = $_REQUEST['date_from'];
        }
        
        if (!empty($_REQUEST['date_to'])) {
            $where .= " AND reservation_date <= %s";
            $where_args[] = $_REQUEST['date_to'];
        }
        
        // Ordering
        $orderby = !empty($_REQUEST['orderby']) ? $_REQUEST['orderby'] : 'reservation_date';
        $order = !empty($_REQUEST['order']) ? $_REQUEST['order'] : 'DESC';
        
        // Get total count
        $total_query = "SELECT COUNT(*) FROM $table_name WHERE $where";
        if (!empty($where_args)) {
            $total_query = $wpdb->prepare($total_query, $where_args);
        }
        $total_items = $wpdb->get_var($total_query);
        
        // Get data
        $offset = ($this->get_pagenum() - 1) * $per_page;
        $data_query = "SELECT * FROM $table_name WHERE $where ORDER BY $orderby $order LIMIT %d OFFSET %d";
        $query_args = array_merge($where_args, array($per_page, $offset));
        $data = $wpdb->get_results($wpdb->prepare($data_query, $query_args));
        
        $this->items = $data;
        
        $this->set_pagination_args(array(
            'total_items' => $total_items,
            'per_page' => $per_page,
            'total_pages' => ceil($total_items / $per_page)
        ));
    }
    
    /**
     * Process bulk actions
     */
    public function process_bulk_action() {
        if ('delete' === $this->current_action()) {
            // Handle single and bulk delete
            $reservations = isset($_REQUEST['reservations']) ? $_REQUEST['reservations'] : array($_REQUEST['reservation']);
            
            foreach ($reservations as $reservation_id) {
                if (wp_verify_nonce($_REQUEST['_wpnonce'], 'delete_reservation_' . $reservation_id) || 
                    wp_verify_nonce($_REQUEST['_wpnonce'], 'bulk-reservations')) {
                    $this->delete_reservation($reservation_id);
                }
            }
        }
        
        if ('approve' === $this->current_action()) {
            $reservations = isset($_REQUEST['reservations']) ? $_REQUEST['reservations'] : array($_REQUEST['reservation']);
            
            foreach ($reservations as $reservation_id) {
                if (wp_verify_nonce($_REQUEST['_wpnonce'], 'approve_reservation_' . $reservation_id) || 
                    wp_verify_nonce($_REQUEST['_wpnonce'], 'bulk-reservations')) {
                    $this->update_reservation_status($reservation_id, 'approved');
                }
            }
        }
        
        if ('decline' === $this->current_action()) {
            $reservations = isset($_REQUEST['reservations']) ? $_REQUEST['reservations'] : array($_REQUEST['reservation']);
            
            foreach ($reservations as $reservation_id) {
                if (wp_verify_nonce($_REQUEST['_wpnonce'], 'decline_reservation_' . $reservation_id) || 
                    wp_verify_nonce($_REQUEST['_wpnonce'], 'bulk-reservations')) {
                    $this->update_reservation_status($reservation_id, 'declined');
                }
            }
        }
    }
    
    /**
     * Delete reservation
     */
    private function delete_reservation($reservation_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'pr_reservations';
        $wpdb->delete($table_name, array('id' => $reservation_id), array('%d'));
    }
    
    /**
     * Update reservation status
     */
    private function update_reservation_status($reservation_id, $status) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'pr_reservations';
        $wpdb->update(
            $table_name,
            array('status' => $status),
            array('id' => $reservation_id),
            array('%s'),
            array('%d')
        );
    }
    
    /**
     * Extra table navigation
     */
    public function extra_tablenav($which) {
        if ('top' === $which) {
            echo '<div class="alignleft actions">';
            
            // Status filter
            $statuses = array(
                'all' => __('All Statuses', 'power-reservations'),
                'pending' => __('Pending', 'power-reservations'),
                'approved' => __('Approved', 'power-reservations'),
                'declined' => __('Declined', 'power-reservations'),
                'cancelled' => __('Cancelled', 'power-reservations')
            );
            
            $current_status = isset($_REQUEST['status']) ? $_REQUEST['status'] : 'all';
            
            echo '<select name="status">';
            foreach ($statuses as $value => $label) {
                printf(
                    '<option value="%s"%s>%s</option>',
                    $value,
                    selected($current_status, $value, false),
                    $label
                );
            }
            echo '</select>';
            
            // Date filters
            echo '<input type="date" name="date_from" value="' . esc_attr(isset($_REQUEST['date_from']) ? $_REQUEST['date_from'] : '') . '" placeholder="' . __('From Date', 'power-reservations') . '">';
            echo '<input type="date" name="date_to" value="' . esc_attr(isset($_REQUEST['date_to']) ? $_REQUEST['date_to'] : '') . '" placeholder="' . __('To Date', 'power-reservations') . '">';
            
            submit_button(__('Filter', 'power-reservations'), 'secondary', 'filter_action', false);
            
            echo '</div>';
        }
    }
}

/**
 * Main Power Reservations Class
 */
class PowerReservations {
    
    private static $instance = null;
    
    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('init', array($this, 'init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    /**
     * Initialize the plugin
     */
    public function init() {
        load_plugin_textdomain('power-reservations', false, dirname(plugin_basename(__FILE__)) . '/languages');
        
        // Admin hooks
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'admin_init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        
        // Shortcodes
        add_shortcode('power_reservations', array($this, 'reservation_shortcode'));
        add_shortcode('my_power_reservations', array($this, 'my_reservations_shortcode'));
        
        // AJAX handlers
        add_action('wp_ajax_pr_submit_reservation', array($this, 'handle_reservation_submission'));
        add_action('wp_ajax_nopriv_pr_submit_reservation', array($this, 'handle_reservation_submission'));
        add_action('wp_ajax_pr_check_availability', array($this, 'check_availability'));
        add_action('wp_ajax_nopriv_pr_check_availability', array($this, 'check_availability'));
        add_action('wp_ajax_pr_cancel_reservation', array($this, 'handle_reservation_cancellation'));
        add_action('wp_ajax_pr_edit_reservation', array($this, 'handle_reservation_edit'));
        
        // Cron hooks
        add_action('pr_send_reminder', array($this, 'send_reminder_email'));
        add_action('pr_daily_cleanup', array($this, 'daily_cleanup'));
        
        // Query vars for reservation management
        add_filter('query_vars', array($this, 'add_query_vars'));
        add_action('wp', array($this, 'handle_reservation_actions'));
        
        // Dashboard widget
        add_action('wp_dashboard_setup', array($this, 'add_dashboard_widget'));
        
        // Schedule cron events if not already scheduled
        if (!wp_next_scheduled('pr_daily_cleanup')) {
            wp_schedule_event(time(), 'daily', 'pr_daily_cleanup');
        }
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        $this->create_database_tables();
        $this->set_default_options();
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        flush_rewrite_rules();
    }
    
    /**
     * Create database tables
     */
    private function create_database_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Main reservations table
        $table_name = $wpdb->prefix . 'pr_reservations';
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            reservation_id varchar(32) NOT NULL,
            user_id bigint(20) UNSIGNED DEFAULT NULL,
            name varchar(100) NOT NULL,
            email varchar(100) NOT NULL,
            phone varchar(20) DEFAULT '',
            reservation_date date NOT NULL,
            reservation_time time NOT NULL,
            party_size int(2) NOT NULL,
            special_requests text DEFAULT '',
            status varchar(20) DEFAULT 'pending',
            admin_notes text DEFAULT '',
            edit_token varchar(64) DEFAULT '',
            reminder_sent tinyint(1) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY reservation_id (reservation_id),
            UNIQUE KEY edit_token (edit_token),
            KEY user_id (user_id),
            KEY reservation_date (reservation_date),
            KEY status (status),
            KEY email (email),
            FOREIGN KEY (user_id) REFERENCES {$wpdb->users}(ID) ON DELETE SET NULL
        ) $charset_collate;";
        
        // Settings table for enhanced configuration
        $settings_table = $wpdb->prefix . 'pr_settings';
        $sql2 = "CREATE TABLE $settings_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            setting_name varchar(100) NOT NULL,
            setting_value longtext DEFAULT '',
            setting_type varchar(50) DEFAULT 'text',
            autoload tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY setting_name (setting_name)
        ) $charset_collate;";
        
        // Email templates table
        $templates_table = $wpdb->prefix . 'pr_email_templates';
        $sql3 = "CREATE TABLE $templates_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            template_name varchar(100) NOT NULL,
            template_subject varchar(255) NOT NULL,
            template_content longtext NOT NULL,
            template_type varchar(50) NOT NULL,
            is_active tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY template_name (template_name),
            KEY template_type (template_type)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        dbDelta($sql2);
        dbDelta($sql3);
        
        // Insert default email templates
        $this->insert_default_email_templates();
        
        add_option('pr_db_version', '2.0');
    }
    
    /**
     * Set default options
     */
    private function set_default_options() {
        $defaults = array(
            'pr_business_name' => get_bloginfo('name'),
            'pr_business_email' => get_option('admin_email'),
            'pr_max_party_size' => 8,
            'pr_booking_window' => 30,
            'pr_time_slots' => array(
                '17:00' => '5:00 PM',
                '17:30' => '5:30 PM',
                '18:00' => '6:00 PM',
                '18:30' => '6:30 PM',
                '19:00' => '7:00 PM',
                '19:30' => '7:30 PM',
                '20:00' => '8:00 PM',
                '20:30' => '8:30 PM',
                '21:00' => '9:00 PM'
            )
        );
        
        foreach ($defaults as $key => $value) {
            if (get_option($key) === false) {
                add_option($key, $value);
            }
        }
        
        // Add enhanced default settings
        $enhanced_defaults = array(
            'pr_max_reservations_per_slot' => 5,
            'pr_edit_window_hours' => 24,
            'pr_require_approval' => false,
            'pr_blackout_dates' => array(),
            'pr_opening_hours' => array(
                'monday' => array('open' => '17:00', 'close' => '22:00'),
                'tuesday' => array('open' => '17:00', 'close' => '22:00'),
                'wednesday' => array('open' => '17:00', 'close' => '22:00'),
                'thursday' => array('open' => '17:00', 'close' => '22:00'),
                'friday' => array('open' => '17:00', 'close' => '22:00'),
                'saturday' => array('open' => '17:00', 'close' => '22:00'),
                'sunday' => array('open' => '17:00', 'close' => '22:00')
            ),
            'pr_time_slot_duration' => 30,
            'pr_form_fields' => array('name', 'email', 'phone', 'date', 'time', 'party_size', 'special_requests'),
            'pr_form_colors' => array(
                'primary' => '#007cba',
                'secondary' => '#50575e',
                'background' => '#ffffff',
                'text' => '#1d2327'
            )
        );
        
        foreach ($enhanced_defaults as $key => $value) {
            if (get_option($key) === false) {
                add_option($key, $value);
            }
        }
    }
    
    /**
     * Insert default email templates
     */
    private function insert_default_email_templates() {
        global $wpdb;
        
        $templates_table = $wpdb->prefix . 'pr_email_templates';
        
        $default_templates = array(
            array(
                'template_name' => 'confirmation',
                'template_subject' => __('Reservation Confirmation - {business_name}', 'power-reservations'),
                'template_content' => '<h2>' . __('Reservation Confirmed!', 'power-reservations') . '</h2>
                    <p>' . __('Dear {name},', 'power-reservations') . '</p>
                    <p>' . __('Thank you for your reservation. Here are the details:', 'power-reservations') . '</p>
                    <ul>
                        <li><strong>' . __('Reservation ID:', 'power-reservations') . '</strong> {reservation_id}</li>
                        <li><strong>' . __('Date:', 'power-reservations') . '</strong> {date}</li>
                        <li><strong>' . __('Time:', 'power-reservations') . '</strong> {time}</li>
                        <li><strong>' . __('Party Size:', 'power-reservations') . '</strong> {party_size}</li>
                    </ul>
                    <p>' . __('You can edit or cancel your reservation using this link:', 'power-reservations') . '</p>
                    <p><a href="{edit_link}">' . __('Manage Reservation', 'power-reservations') . '</a></p>
                    <p>' . __('We look forward to seeing you!', 'power-reservations') . '</p>',
                'template_type' => 'user'
            ),
            array(
                'template_name' => 'reminder',
                'template_subject' => __('Reservation Reminder - {business_name}', 'power-reservations'),
                'template_content' => '<h2>' . __('Reservation Reminder', 'power-reservations') . '</h2>
                    <p>' . __('Dear {name},', 'power-reservations') . '</p>
                    <p>' . __('This is a friendly reminder about your reservation today:', 'power-reservations') . '</p>
                    <ul>
                        <li><strong>' . __('Date:', 'power-reservations') . '</strong> {date}</li>
                        <li><strong>' . __('Time:', 'power-reservations') . '</strong> {time}</li>
                        <li><strong>' . __('Party Size:', 'power-reservations') . '</strong> {party_size}</li>
                    </ul>
                    <p>' . __('We look forward to seeing you!', 'power-reservations') . '</p>',
                'template_type' => 'user'
            ),
            array(
                'template_name' => 'admin_notification',
                'template_subject' => __('New Reservation - {business_name}', 'power-reservations'),
                'template_content' => '<h2>' . __('New Reservation Received', 'power-reservations') . '</h2>
                    <p>' . __('A new reservation has been submitted:', 'power-reservations') . '</p>
                    <ul>
                        <li><strong>' . __('Name:', 'power-reservations') . '</strong> {name}</li>
                        <li><strong>' . __('Email:', 'power-reservations') . '</strong> {email}</li>
                        <li><strong>' . __('Phone:', 'power-reservations') . '</strong> {phone}</li>
                        <li><strong>' . __('Date:', 'power-reservations') . '</strong> {date}</li>
                        <li><strong>' . __('Time:', 'power-reservations') . '</strong> {time}</li>
                        <li><strong>' . __('Party Size:', 'power-reservations') . '</strong> {party_size}</li>
                        <li><strong>' . __('Special Requests:', 'power-reservations') . '</strong> {special_requests}</li>
                    </ul>
                    <p><a href="{admin_link}">' . __('Manage Reservations', 'power-reservations') . '</a></p>',
                'template_type' => 'admin'
            )
        );
        
        foreach ($default_templates as $template) {
            $wpdb->replace(
                $templates_table,
                $template,
                array('%s', '%s', '%s', '%s')
            );
        }
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // Main menu page
        add_menu_page(
            __('Power Reservations', 'power-reservations'),
            __('Reservations', 'power-reservations'),
            'manage_options',
            'power-reservations',
            array($this, 'admin_page'),
            'dashicons-calendar-alt',
            30
        );
        
        // All Reservations (uses WP_List_Table)
        add_submenu_page(
            'power-reservations',
            __('All Reservations', 'power-reservations'),
            __('All Reservations', 'power-reservations'),
            'manage_options',
            'power-reservations',
            array($this, 'admin_page')
        );
        
        // Settings
        add_submenu_page(
            'power-reservations',
            __('Settings', 'power-reservations'),
            __('Settings', 'power-reservations'),
            'manage_options',
            'pr-settings',
            array($this, 'settings_page')
        );
        
        // Email Templates
        add_submenu_page(
            'power-reservations',
            __('Email Templates', 'power-reservations'),
            __('Email Templates', 'power-reservations'),
            'manage_options',
            'pr-email-templates',
            array($this, 'email_templates_page')
        );
        
        // Form Builder
        add_submenu_page(
            'power-reservations',
            __('Form Builder', 'power-reservations'),
            __('Form Builder', 'power-reservations'),
            'manage_options',
            'pr-form-builder',
            array($this, 'form_builder_page')
        );
        
        // Form Styling
        add_submenu_page(
            'power-reservations',
            __('Form Styling', 'power-reservations'),
            __('Form Styling', 'power-reservations'),
            'manage_options',
            'pr-form-styling',
            array($this, 'form_styling_page')
        );
    }
    
    /**
     * Admin page
     */
    public function admin_page() {
        // Handle individual actions (edit, etc.)
        if (isset($_GET['action']) && isset($_GET['reservation'])) {
            $this->handle_admin_action();
            return;
        }
        
        // Create list table instance
        $list_table = new PR_Reservations_List_Table();
        $list_table->prepare_items();
        
        echo '<div class="wrap">';
        echo '<h1 class="wp-heading-inline">' . __('All Reservations', 'power-reservations') . '</h1>';
        echo '<a href="' . admin_url('admin.php?page=pr-form-builder') . '" class="page-title-action">' . __('Form Builder', 'power-reservations') . '</a>';
        echo '<hr class="wp-header-end">';
        
        // Show notices
        if (isset($_GET['message'])) {
            $message = '';
            switch ($_GET['message']) {
                case 'approved':
                    $message = __('Reservation approved successfully.', 'power-reservations');
                    break;
                case 'declined':
                    $message = __('Reservation declined successfully.', 'power-reservations');
                    break;
                case 'deleted':
                    $message = __('Reservation deleted successfully.', 'power-reservations');
                    break;
                case 'updated':
                    $message = __('Reservation updated successfully.', 'power-reservations');
                    break;
            }
            if ($message) {
                echo '<div class="notice notice-success is-dismissible"><p>' . $message . '</p></div>';
            }
        }
        
        // Stats overview
        global $wpdb;
        $table_name = $wpdb->prefix . 'pr_reservations';
        $today = date('Y-m-d');
        
        $stats = array(
            'total' => $wpdb->get_var("SELECT COUNT(*) FROM $table_name"),
            'pending' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE status = %s", 'pending')),
            'today' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE reservation_date = %s", $today)),
            'upcoming' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE reservation_date > %s AND status = %s", $today, 'approved'))
        );
        
        echo '<div class="pr-stats-grid">';
        echo '<div class="pr-stat-box">';
        echo '<div class="pr-stat-number">' . $stats['total'] . '</div>';
        echo '<div class="pr-stat-label">' . __('Total Reservations', 'power-reservations') . '</div>';
        echo '</div>';
        echo '<div class="pr-stat-box">';
        echo '<div class="pr-stat-number pr-stat-pending">' . $stats['pending'] . '</div>';
        echo '<div class="pr-stat-label">' . __('Pending Approval', 'power-reservations') . '</div>';
        echo '</div>';
        echo '<div class="pr-stat-box">';
        echo '<div class="pr-stat-number pr-stat-today">' . $stats['today'] . '</div>';
        echo '<div class="pr-stat-label">' . __('Today\'s Reservations', 'power-reservations') . '</div>';
        echo '</div>';
        echo '<div class="pr-stat-box">';
        echo '<div class="pr-stat-number pr-stat-upcoming">' . $stats['upcoming'] . '</div>';
        echo '<div class="pr-stat-label">' . __('Upcoming Approved', 'power-reservations') . '</div>';
        echo '</div>';
        echo '</div>';
        
        // Search form
        echo '<form method="get">';
        echo '<input type="hidden" name="page" value="' . $_REQUEST['page'] . '">';
        $list_table->search_box(__('Search Reservations', 'power-reservations'), 'reservation');
        echo '</form>';
        
        // List table
        echo '<form method="post">';
        $list_table->display();
        echo '</form>';
        
        echo '<div class="pr-quick-actions">';
        echo '<h3>' . __('Quick Actions', 'power-reservations') . '</h3>';
        echo '<p>' . __('Shortcode for reservation form:', 'power-reservations') . ' <code>[power_reservations]</code></p>';
        echo '<p>' . __('Shortcode for user reservations:', 'power-reservations') . ' <code>[my_power_reservations]</code></p>';
        echo '<p><a href="' . admin_url('admin.php?page=pr-settings') . '" class="button">' . __('Settings', 'power-reservations') . '</a> ';
        echo '<a href="' . admin_url('admin.php?page=pr-email-templates') . '" class="button">' . __('Email Templates', 'power-reservations') . '</a></p>';
        echo '</div>';
        
        echo '</div>';
    }
    
    /**
     * Handle admin actions
     */
    private function handle_admin_action() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'power-reservations'));
        }
        
        $action = $_GET['action'];
        $reservation_id = intval($_GET['reservation']);
        
        if ($action === 'edit') {
            $this->edit_reservation_page($reservation_id);
        } elseif ($action === 'view') {
            $this->view_reservation_page($reservation_id);
        } else {
            wp_redirect(admin_url('admin.php?page=power-reservations'));
            exit;
        }
    }
    
    /**
     * Edit reservation page
     */
    private function edit_reservation_page($reservation_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'pr_reservations';
        $reservation = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $reservation_id));
        
        if (!$reservation) {
            wp_die(__('Reservation not found.', 'power-reservations'));
        }
        
        // Handle form submission
        if (isset($_POST['submit'])) {
            $wpdb->update(
                $table_name,
                array(
                    'name' => sanitize_text_field($_POST['name']),
                    'email' => sanitize_email($_POST['email']),
                    'phone' => sanitize_text_field($_POST['phone']),
                    'reservation_date' => sanitize_text_field($_POST['reservation_date']),
                    'reservation_time' => sanitize_text_field($_POST['reservation_time']),
                    'party_size' => intval($_POST['party_size']),
                    'special_requests' => sanitize_textarea_field($_POST['special_requests']),
                    'status' => sanitize_text_field($_POST['status']),
                    'admin_notes' => sanitize_textarea_field($_POST['admin_notes'])
                ),
                array('id' => $reservation_id),
                array('%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s'),
                array('%d')
            );
            
            wp_redirect(admin_url('admin.php?page=power-reservations&message=updated'));
            exit;
        }
        
        echo '<div class="wrap">';
        echo '<h1>' . __('Edit Reservation', 'power-reservations') . '</h1>';
        echo '<form method="post">';
        echo '<table class="form-table">';
        
        echo '<tr><th scope="row">' . __('Name', 'power-reservations') . '</th>';
        echo '<td><input type="text" name="name" value="' . esc_attr($reservation->name) . '" class="regular-text" required /></td></tr>';
        
        echo '<tr><th scope="row">' . __('Email', 'power-reservations') . '</th>';
        echo '<td><input type="email" name="email" value="' . esc_attr($reservation->email) . '" class="regular-text" required /></td></tr>';
        
        echo '<tr><th scope="row">' . __('Phone', 'power-reservations') . '</th>';
        echo '<td><input type="text" name="phone" value="' . esc_attr($reservation->phone) . '" class="regular-text" /></td></tr>';
        
        echo '<tr><th scope="row">' . __('Date', 'power-reservations') . '</th>';
        echo '<td><input type="date" name="reservation_date" value="' . esc_attr($reservation->reservation_date) . '" required /></td></tr>';
        
        echo '<tr><th scope="row">' . __('Time', 'power-reservations') . '</th>';
        echo '<td><input type="time" name="reservation_time" value="' . esc_attr($reservation->reservation_time) . '" required /></td></tr>';
        
        echo '<tr><th scope="row">' . __('Party Size', 'power-reservations') . '</th>';
        echo '<td><input type="number" name="party_size" value="' . esc_attr($reservation->party_size) . '" min="1" max="20" required /></td></tr>';
        
        echo '<tr><th scope="row">' . __('Special Requests', 'power-reservations') . '</th>';
        echo '<td><textarea name="special_requests" rows="3" class="large-text">' . esc_textarea($reservation->special_requests) . '</textarea></td></tr>';
        
        echo '<tr><th scope="row">' . __('Status', 'power-reservations') . '</th>';
        echo '<td><select name="status">';
        $statuses = array('pending', 'approved', 'declined', 'cancelled');
        foreach ($statuses as $status) {
            echo '<option value="' . $status . '"' . selected($reservation->status, $status, false) . '>' . ucfirst($status) . '</option>';
        }
        echo '</select></td></tr>';
        
        echo '<tr><th scope="row">' . __('Admin Notes', 'power-reservations') . '</th>';
        echo '<td><textarea name="admin_notes" rows="3" class="large-text">' . esc_textarea($reservation->admin_notes) . '</textarea></td></tr>';
        
        echo '</table>';
        submit_button(__('Update Reservation', 'power-reservations'));
        echo '</form>';
        echo '<p><a href="' . admin_url('admin.php?page=power-reservations') . '">' . __('← Back to Reservations', 'power-reservations') . '</a></p>';
        echo '</div>';
    }
    
    /**
     * View reservation page
     */
    private function view_reservation_page($reservation_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'pr_reservations';
        $reservation = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $reservation_id));
        
        if (!$reservation) {
            wp_die(__('Reservation not found.', 'power-reservations'));
        }
        
        echo '<div class="wrap">';
        echo '<h1>' . __('View Reservation', 'power-reservations') . '</h1>';
        echo '<div class="card">';
        echo '<h2>' . esc_html($reservation->name) . '</h2>';
        echo '<p><strong>' . __('Reservation ID:', 'power-reservations') . '</strong> ' . esc_html($reservation->reservation_id) . '</p>';
        echo '<p><strong>' . __('Email:', 'power-reservations') . '</strong> ' . esc_html($reservation->email) . '</p>';
        echo '<p><strong>' . __('Phone:', 'power-reservations') . '</strong> ' . esc_html($reservation->phone) . '</p>';
        echo '<p><strong>' . __('Date:', 'power-reservations') . '</strong> ' . esc_html($reservation->reservation_date) . '</p>';
        echo '<p><strong>' . __('Time:', 'power-reservations') . '</strong> ' . esc_html($reservation->reservation_time) . '</p>';
        echo '<p><strong>' . __('Party Size:', 'power-reservations') . '</strong> ' . esc_html($reservation->party_size) . '</p>';
        echo '<p><strong>' . __('Status:', 'power-reservations') . '</strong> ' . esc_html(ucfirst($reservation->status)) . '</p>';
        if ($reservation->special_requests) {
            echo '<p><strong>' . __('Special Requests:', 'power-reservations') . '</strong><br>' . esc_html($reservation->special_requests) . '</p>';
        }
        if ($reservation->admin_notes) {
            echo '<p><strong>' . __('Admin Notes:', 'power-reservations') . '</strong><br>' . esc_html($reservation->admin_notes) . '</p>';
        }
        echo '<p><strong>' . __('Created:', 'power-reservations') . '</strong> ' . esc_html($reservation->created_at) . '</p>';
        echo '</div>';
        echo '<p><a href="' . admin_url('admin.php?page=power-reservations&action=edit&reservation=' . $reservation_id) . '" class="button button-primary">' . __('Edit Reservation', 'power-reservations') . '</a></p>';
        echo '<p><a href="' . admin_url('admin.php?page=power-reservations') . '">' . __('← Back to Reservations', 'power-reservations') . '</a></p>';
        echo '</div>';
    }
    
    /**
     * Settings page
     */
    public function settings_page() {
        if (isset($_POST['submit'])) {
            update_option('pr_business_name', sanitize_text_field($_POST['pr_business_name']));
            update_option('pr_business_email', sanitize_email($_POST['pr_business_email']));
            update_option('pr_max_party_size', intval($_POST['pr_max_party_size']));
            update_option('pr_booking_window', intval($_POST['pr_booking_window']));
            
            echo '<div class="notice notice-success"><p>' . __('Settings saved!', 'power-reservations') . '</p></div>';
        }
        
        $business_name = get_option('pr_business_name', get_bloginfo('name'));
        $business_email = get_option('pr_business_email', get_option('admin_email'));
        $max_party_size = get_option('pr_max_party_size', 8);
        $booking_window = get_option('pr_booking_window', 30);
        
        echo '<div class="wrap">';
        echo '<h1>' . __('Reservation Settings', 'power-reservations') . '</h1>';
        echo '<form method="post" action="">';
        echo '<table class="form-table">';
        echo '<tr><th scope="row">' . __('Business Name', 'power-reservations') . '</th>';
        echo '<td><input type="text" name="pr_business_name" value="' . esc_attr($business_name) . '" class="regular-text" /></td></tr>';
        echo '<tr><th scope="row">' . __('Business Email', 'power-reservations') . '</th>';
        echo '<td><input type="email" name="pr_business_email" value="' . esc_attr($business_email) . '" class="regular-text" /></td></tr>';
        echo '<tr><th scope="row">' . __('Maximum Party Size', 'power-reservations') . '</th>';
        echo '<td><input type="number" name="pr_max_party_size" value="' . esc_attr($max_party_size) . '" min="1" max="20" /></td></tr>';
        echo '<tr><th scope="row">' . __('Booking Window (days)', 'power-reservations') . '</th>';
        echo '<td><input type="number" name="pr_booking_window" value="' . esc_attr($booking_window) . '" min="1" max="365" /></td></tr>';
        echo '</table>';
        submit_button();
        echo '</form>';
        echo '</div>';
    }
    
    /**
     * Email Templates page
     */
    public function email_templates_page() {
        echo '<div class="wrap">';
        echo '<h1>' . __('Email Templates', 'power-reservations') . '</h1>';
        echo '<p>' . __('Customize email templates sent to customers and administrators.', 'power-reservations') . '</p>';
        
        // Handle form submission
        if (isset($_POST['template_name'])) {
            global $wpdb;
            $templates_table = $wpdb->prefix . 'pr_email_templates';
            
            $wpdb->replace(
                $templates_table,
                array(
                    'template_name' => sanitize_text_field($_POST['template_name']),
                    'template_subject' => sanitize_text_field($_POST['template_subject']),
                    'template_content' => wp_kses_post($_POST['template_content']),
                    'template_type' => sanitize_text_field($_POST['template_type']),
                    'is_active' => isset($_POST['is_active']) ? 1 : 0
                ),
                array('%s', '%s', '%s', '%s', '%d')
            );
            
            echo '<div class="notice notice-success"><p>' . __('Template saved successfully!', 'power-reservations') . '</p></div>';
        }
        
        global $wpdb;
        $templates_table = $wpdb->prefix . 'pr_email_templates';
        $templates = $wpdb->get_results("SELECT * FROM $templates_table ORDER BY template_type, template_name");
        
        echo '<div class="pr-templates-grid">';
        foreach ($templates as $template) {
            echo '<div class="pr-template-card">';
            echo '<h3>' . esc_html(ucwords(str_replace('_', ' ', $template->template_name))) . '</h3>';
            echo '<p><strong>' . __('Subject:', 'power-reservations') . '</strong> ' . esc_html($template->template_subject) . '</p>';
            echo '<p><strong>' . __('Type:', 'power-reservations') . '</strong> ' . esc_html(ucfirst($template->template_type)) . '</p>';
            echo '<p><strong>' . __('Status:', 'power-reservations') . '</strong> ' . ($template->is_active ? __('Active', 'power-reservations') : __('Inactive', 'power-reservations')) . '</p>';
            echo '<a href="?page=pr-email-templates&edit=' . $template->id . '" class="button">' . __('Edit', 'power-reservations') . '</a>';
            echo '</div>';
        }
        echo '</div>';
        
        echo '<p>' . __('Available placeholders: {name}, {email}, {phone}, {date}, {time}, {party_size}, {special_requests}, {business_name}, {reservation_id}, {edit_link}, {admin_link}', 'power-reservations') . '</p>';
        echo '</div>';
    }
    
    /**
     * Form Builder page
     */
    public function form_builder_page() {
        echo '<div class="wrap">';
        echo '<h1 class="wp-heading-inline">' . __('Form Builder', 'power-reservations') . '</h1>';
        echo '<hr class="wp-header-end">';
        
        // Handle form submission
        if (isset($_POST['submit_form_builder'])) {
            // Save styling mode
            update_option('pr_styling_mode', sanitize_text_field($_POST['styling_mode']));
            
            // Save form fields
            $enabled_fields = isset($_POST['form_fields']) ? array_map('sanitize_text_field', $_POST['form_fields']) : array();
            update_option('pr_form_fields', $enabled_fields);
            
            // Save field settings
            $field_settings = array();
            $available_fields = array('name', 'email', 'phone', 'date', 'time', 'party_size', 'special_requests');
            
            foreach ($available_fields as $field) {
                if (isset($_POST[$field . '_label'])) {
                    $field_settings[$field]['label'] = sanitize_text_field($_POST[$field . '_label']);
                }
                if (isset($_POST[$field . '_placeholder'])) {
                    $field_settings[$field]['placeholder'] = sanitize_text_field($_POST[$field . '_placeholder']);
                }
                $field_settings[$field]['required'] = isset($_POST[$field . '_required']);
            }
            update_option('pr_form_field_settings', $field_settings);
            
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Form configuration saved successfully!', 'power-reservations') . '</p></div>';
        }
        
        // Get current settings
        $styling_mode = get_option('pr_styling_mode', 'custom');
        $available_fields = array(
            'name' => array(
                'label' => __('Name', 'power-reservations'),
                'icon' => '👤',
                'type' => 'text',
                'required_default' => true
            ),
            'email' => array(
                'label' => __('Email', 'power-reservations'),
                'icon' => '📧',
                'type' => 'email',
                'required_default' => true
            ),
            'phone' => array(
                'label' => __('Phone', 'power-reservations'),
                'icon' => '📱',
                'type' => 'tel',
                'required_default' => false
            ),
            'date' => array(
                'label' => __('Date', 'power-reservations'),
                'icon' => '📅',
                'type' => 'date',
                'required_default' => true
            ),
            'time' => array(
                'label' => __('Time', 'power-reservations'),
                'icon' => '🕐',
                'type' => 'select',
                'required_default' => true
            ),
            'party_size' => array(
                'label' => __('Party Size', 'power-reservations'),
                'icon' => '👥',
                'type' => 'select',
                'required_default' => true
            ),
            'special_requests' => array(
                'label' => __('Special Requests', 'power-reservations'),
                'icon' => '💬',
                'type' => 'textarea',
                'required_default' => false
            )
        );
        
        $current_fields = get_option('pr_form_fields', array_keys($available_fields));
        $field_settings = get_option('pr_form_field_settings', array());
        
        echo '<form method="post" id="pr-form-builder-form">';
        wp_nonce_field('pr_form_builder', 'pr_form_builder_nonce');
        
        // Styling Mode Section
        echo '<div id="pr-form-builder">';
        echo '<div class="pr-form-builder-header">';
        echo '<h3>' . __('Form Builder & Styling', 'power-reservations') . '</h3>';
        echo '</div>';
        
        echo '<div class="pr-form-builder-content">';
        
        // Styling Mode Selector
        echo '<div class="pr-styling-mode">';
        echo '<h4>' . __('Styling Mode', 'power-reservations') . '</h4>';
        echo '<p>' . __('Choose how you want to style your reservation form:', 'power-reservations') . '</p>';
        
        echo '<div class="pr-styling-options">';
        
        // Use Current Theme Option
        echo '<div class="pr-styling-option ' . ($styling_mode === 'theme' ? 'active' : '') . '" onclick="selectStylingMode(\'theme\')">';
        echo '<input type="radio" name="styling_mode" value="theme" id="styling_theme"' . checked($styling_mode, 'theme', false) . '>';
        echo '<h5>' . __('🎨 Use Current Theme', 'power-reservations') . '</h5>';
        echo '<p>' . __('Automatically inherit colors, fonts, and styling from your active WordPress theme. Perfect for seamless integration.', 'power-reservations') . '</p>';
        echo '</div>';
        
        // Custom Styling Option
        echo '<div class="pr-styling-option ' . ($styling_mode === 'custom' ? 'active' : '') . '" onclick="selectStylingMode(\'custom\')">';
        echo '<input type="radio" name="styling_mode" value="custom" id="styling_custom"' . checked($styling_mode, 'custom', false) . '>';
        echo '<h5>' . __('🎛️ Custom Styling', 'power-reservations') . '</h5>';
        echo '<p>' . __('Use the Form Styling page to customize colors, fonts, and appearance exactly how you want them.', 'power-reservations') . '</p>';
        echo '</div>';
        
        // Minimal Styling Option
        echo '<div class="pr-styling-option ' . ($styling_mode === 'minimal' ? 'active' : '') . '" onclick="selectStylingMode(\'minimal\')">';
        echo '<input type="radio" name="styling_mode" value="minimal" id="styling_minimal"' . checked($styling_mode, 'minimal', false) . '>';
        echo '<h5>' . __('🎯 Minimal Style', 'power-reservations') . '</h5>';
        echo '<p>' . __('Clean, minimal styling that works with any theme. Great for maximum compatibility.', 'power-reservations') . '</p>';
        echo '</div>';
        
        echo '</div>'; // .pr-styling-options
        echo '</div>'; // .pr-styling-mode
        
        // Field Configuration Section
        echo '<div class="pr-field-configuration">';
        echo '<h4>' . __('Form Fields Configuration', 'power-reservations') . '</h4>';
        echo '<p>' . __('Drag to reorder, toggle to enable/disable, and customize each field:', 'power-reservations') . '</p>';
        
        echo '<div class="pr-field-items" id="pr-sortable-fields">';
        
        foreach ($available_fields as $field_key => $field_info) {
            $is_enabled = in_array($field_key, $current_fields);
            $is_required = isset($field_settings[$field_key]['required']) ? $field_settings[$field_key]['required'] : $field_info['required_default'];
            $custom_label = isset($field_settings[$field_key]['label']) ? $field_settings[$field_key]['label'] : $field_info['label'];
            $placeholder = isset($field_settings[$field_key]['placeholder']) ? $field_settings[$field_key]['placeholder'] : '';
            
            echo '<div class="pr-field-config ' . ($is_enabled ? 'pr-field-enabled' : 'pr-field-disabled') . '" data-field="' . $field_key . '">';
            echo '<div class="pr-drag-handle">⋮⋮</div>';
            
            // Field Header
            echo '<div class="pr-field-header">';
            echo '<div class="pr-field-title">';
            echo '<span class="pr-field-icon">' . $field_info['icon'] . '</span>';
            echo '<span>' . $field_info['label'] . ' (' . ucfirst($field_info['type']) . ')</span>';
            if ($field_info['required_default']) {
                echo '<span class="pr-required-field">*</span>';
            }
            echo '</div>';
            
            echo '<div class="pr-field-toggle">';
            echo '<input type="checkbox" name="form_fields[]" value="' . $field_key . '" id="toggle_' . $field_key . '"' . checked($is_enabled, true, false) . ' onchange="toggleField(\'' . $field_key . '\')">';
            echo '<span class="pr-toggle-slider"></span>';
            echo '</div>';
            
            echo '</div>'; // .pr-field-header
            
            // Field Options
            echo '<div class="pr-field-options">';
            echo '<div class="pr-field-options-grid">';
            
            echo '<div>';
            echo '<label for="' . $field_key . '_label">' . __('Field Label', 'power-reservations') . '</label>';
            echo '<input type="text" name="' . $field_key . '_label" id="' . $field_key . '_label" value="' . esc_attr($custom_label) . '" placeholder="' . esc_attr($field_info['label']) . '">';
            echo '</div>';
            
            echo '<div>';
            echo '<label for="' . $field_key . '_placeholder">' . __('Placeholder Text', 'power-reservations') . '</label>';
            echo '<input type="text" name="' . $field_key . '_placeholder" id="' . $field_key . '_placeholder" value="' . esc_attr($placeholder) . '" placeholder="' . __('Enter placeholder...', 'power-reservations') . '">';
            echo '</div>';
            
            echo '</div>'; // .pr-field-options-grid
            
            if (!$field_info['required_default']) {
                echo '<div style="margin-top: 10px;">';
                echo '<label>';
                echo '<input type="checkbox" name="' . $field_key . '_required" value="1"' . checked($is_required, true, false) . '>';
                echo __('Required Field', 'power-reservations');
                echo '</label>';
                echo '</div>';
            }
            
            echo '</div>'; // .pr-field-options
            echo '</div>'; // .pr-field-config
        }
        
        echo '</div>'; // .pr-field-items
        echo '</div>'; // .pr-field-configuration
        
        echo '</div>'; // .pr-form-builder-content
        echo '</div>'; // #pr-form-builder
        
        // Action Buttons
        echo '<div style="margin: 20px 0; text-align: center;">';
        echo '<button type="submit" name="submit_form_builder" class="button button-primary button-large" style="margin-right: 10px;">' . __('💾 Save Configuration', 'power-reservations') . '</button>';
        echo '<a href="' . admin_url('admin.php?page=pr-form-styling') . '" class="button button-secondary button-large">' . __('🎨 Advanced Styling', 'power-reservations') . '</a>';
        echo '</div>';
        
        echo '</form>';
        
        // Live Preview Section
        echo '<div class="pr-form-preview">';
        echo '<h2>' . __('📱 Live Preview', 'power-reservations') . '</h2>';
        echo '<p>' . __('This is how your form will appear to visitors:', 'power-reservations') . '</p>';
        echo '<div id="pr-live-preview">';
        echo do_shortcode('[power_reservations]');
        echo '</div>';
        echo '</div>';
        
        // Add JavaScript for interactivity
        echo '<script>
        function selectStylingMode(mode) {
            document.getElementById("styling_" + mode).checked = true;
            document.querySelectorAll(".pr-styling-option").forEach(el => el.classList.remove("active"));
            event.currentTarget.classList.add("active");
        }
        
        function toggleField(fieldKey) {
            const fieldConfig = document.querySelector(\'.pr-field-config[data-field="\' + fieldKey + \'"]\');
            const checkbox = document.getElementById("toggle_" + fieldKey);
            
            if (checkbox.checked) {
                fieldConfig.classList.remove("pr-field-disabled");
                fieldConfig.classList.add("pr-field-enabled");
            } else {
                fieldConfig.classList.remove("pr-field-enabled");
                fieldConfig.classList.add("pr-field-disabled");
            }
        }
        
        // Initialize sortable (if jQuery UI is available)
        jQuery(document).ready(function($) {
            if ($.fn.sortable) {
                $("#pr-sortable-fields").sortable({
                    handle: ".pr-drag-handle",
                    placeholder: "pr-field-placeholder",
                    opacity: 0.8,
                    cursor: "move"
                });
            }
        });
        </script>';
        
        echo '</div>';
    }
    
    /**
     * Form Styling page
     */
    public function form_styling_page() {
        echo '<div class="wrap">';
        echo '<h1>' . __('Form Styling', 'power-reservations') . '</h1>';
        echo '<p>' . __('Customize the appearance of your reservation form.', 'power-reservations') . '</p>';
        
        // Handle form submission
        if (isset($_POST['form_colors'])) {
            update_option('pr_form_colors', array_map('sanitize_hex_color', $_POST['form_colors']));
            
            if (isset($_POST['custom_css'])) {
                update_option('pr_custom_css', wp_strip_all_tags($_POST['custom_css']));
            }
            
            echo '<div class="notice notice-success"><p>' . __('Styling saved!', 'power-reservations') . '</p></div>';
        }
        
        $form_colors = get_option('pr_form_colors', array(
            'primary' => '#007cba',
            'secondary' => '#50575e',
            'background' => '#ffffff',
            'text' => '#1d2327'
        ));
        
        $custom_css = get_option('pr_custom_css', '');
        
        echo '<form method="post">';
        echo '<h2>' . __('Color Settings', 'power-reservations') . '</h2>';
        echo '<table class="form-table">';
        
        echo '<tr><th scope="row">' . __('Primary Color', 'power-reservations') . '</th>';
        echo '<td><input type="color" name="form_colors[primary]" value="' . esc_attr($form_colors['primary']) . '"></td></tr>';
        
        echo '<tr><th scope="row">' . __('Secondary Color', 'power-reservations') . '</th>';
        echo '<td><input type="color" name="form_colors[secondary]" value="' . esc_attr($form_colors['secondary']) . '"></td></tr>';
        
        echo '<tr><th scope="row">' . __('Background Color', 'power-reservations') . '</th>';
        echo '<td><input type="color" name="form_colors[background]" value="' . esc_attr($form_colors['background']) . '"></td></tr>';
        
        echo '<tr><th scope="row">' . __('Text Color', 'power-reservations') . '</th>';
        echo '<td><input type="color" name="form_colors[text]" value="' . esc_attr($form_colors['text']) . '"></td></tr>';
        
        echo '</table>';
        
        echo '<h2>' . __('Custom CSS', 'power-reservations') . '</h2>';
        echo '<p>' . __('Add custom CSS to further customize your form appearance:', 'power-reservations') . '</p>';
        echo '<textarea name="custom_css" rows="10" cols="80" class="large-text code">' . esc_textarea($custom_css) . '</textarea>';
        
        submit_button(__('Save Styling', 'power-reservations'));
        echo '</form>';
        
        echo '<h2>' . __('Form Preview', 'power-reservations') . '</h2>';
        echo '<div class="pr-form-preview">';
        echo do_shortcode('[power_reservations]');
        echo '</div>';
        
        echo '</div>';
    }
    
    /**
     * Enqueue frontend scripts
     */
    public function enqueue_scripts() {
        // Enqueue jQuery UI for datepicker
        wp_enqueue_script('jquery-ui-datepicker');
        wp_enqueue_style('jquery-ui-style', 'https://code.jquery.com/ui/1.13.2/themes/ui-lightness/jquery-ui.css', array(), '1.13.2');
        
        // Enqueue plugin scripts
        wp_enqueue_script('pr-frontend', PR_PLUGIN_URL . 'assets/frontend.js', array('jquery', 'jquery-ui-datepicker'), PR_VERSION, true);
        wp_enqueue_style('pr-frontend', PR_PLUGIN_URL . 'assets/frontend.css', array('jquery-ui-style'), PR_VERSION);
        
        // Add dynamic CSS for custom colors
        $form_colors = get_option('pr_form_colors', array(
            'primary' => '#007cba',
            'secondary' => '#50575e',
            'background' => '#ffffff',
            'text' => '#1d2327'
        ));
        
        $custom_css = "
        .pr-reservation-wrapper {
            --pr-primary: {$form_colors['primary']};
            --pr-secondary: {$form_colors['secondary']};
            --pr-background: {$form_colors['background']};
            --pr-text: {$form_colors['text']};
        }
        ";
        
        $user_custom_css = get_option('pr_custom_css', '');
        if ($user_custom_css) {
            $custom_css .= "\n" . $user_custom_css;
        }
        
        wp_add_inline_style('pr-frontend', $custom_css);
        
        // Localize script with enhanced data
        wp_localize_script('pr-frontend', 'pr_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('pr_nonce'),
            'booking_window' => get_option('pr_booking_window', 30),
            'blackout_dates' => get_option('pr_blackout_dates', array()),
            'strings' => array(
                'loading' => __('Loading...', 'power-reservations'),
                'checking_availability' => __('Checking availability...', 'power-reservations'),
                'no_times_available' => __('No times available for this date.', 'power-reservations'),
                'reservation_success' => __('Reservation submitted successfully!', 'power-reservations'),
                'reservation_error' => __('Error submitting reservation. Please try again.', 'power-reservations'),
                'required_fields' => __('Please fill in all required fields.', 'power-reservations'),
                'invalid_email' => __('Please enter a valid email address.', 'power-reservations')
            )
        ));
    }
    
    /**
     * Enqueue admin scripts
     */
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'power-reservations') !== false) {
            wp_enqueue_style('pr-admin', PR_PLUGIN_URL . 'assets/admin.css', array(), PR_VERSION);
        }
    }
    
    /**
     * Reservation shortcode
     */
    public function reservation_shortcode($atts) {
        $atts = shortcode_atts(array('style' => 'default'), $atts);
        
        ob_start();
        $this->render_reservation_form();
        return ob_get_clean();
    }
    
    /**
     * Render reservation form
     */
    private function render_reservation_form() {
        $time_slots = get_option('pr_time_slots', array());
        $max_party_size = get_option('pr_max_party_size', 8);
        $booking_window = get_option('pr_booking_window', 30);
        
        $min_date = date('Y-m-d', strtotime('+1 day'));
        $max_date = date('Y-m-d', strtotime("+{$booking_window} days"));
        
        echo '<div id="pr-reservation-form" class="pr-reservation-wrapper">';
        echo '<h3>' . __('Make a Reservation', 'power-reservations') . '</h3>';
        echo '<form id="pr-form" class="pr-form">';
        wp_nonce_field('pr_nonce', 'pr_nonce');
        
        echo '<div class="pr-form-row">';
        echo '<label for="pr-name">' . __('Name *', 'power-reservations') . '</label>';
        echo '<input type="text" id="pr-name" name="name" required>';
        echo '</div>';
        
        echo '<div class="pr-form-row">';
        echo '<label for="pr-email">' . __('Email *', 'power-reservations') . '</label>';
        echo '<input type="email" id="pr-email" name="email" required>';
        echo '</div>';
        
        echo '<div class="pr-form-row">';
        echo '<label for="pr-phone">' . __('Phone', 'power-reservations') . '</label>';
        echo '<input type="tel" id="pr-phone" name="phone">';
        echo '</div>';
        
        echo '<div class="pr-form-row">';
        echo '<label for="pr-date">' . __('Date *', 'power-reservations') . '</label>';
        echo '<input type="date" id="pr-date" name="date" min="' . $min_date . '" max="' . $max_date . '" required>';
        echo '</div>';
        
        echo '<div class="pr-form-row">';
        echo '<label for="pr-time">' . __('Time *', 'power-reservations') . '</label>';
        echo '<select id="pr-time" name="time" required>';
        echo '<option value="">' . __('Select a time', 'power-reservations') . '</option>';
        foreach ($time_slots as $value => $label) {
            echo '<option value="' . esc_attr($value) . '">' . esc_html($label) . '</option>';
        }
        echo '</select>';
        echo '</div>';
        
        echo '<div class="pr-form-row">';
        echo '<label for="pr-party-size">' . __('Party Size *', 'power-reservations') . '</label>';
        echo '<select id="pr-party-size" name="party_size" required>';
        echo '<option value="">' . __('Select party size', 'power-reservations') . '</option>';
        for ($i = 1; $i <= $max_party_size; $i++) {
            $person_text = $i == 1 ? __('person', 'power-reservations') : __('people', 'power-reservations');
            echo '<option value="' . $i . '">' . $i . ' ' . $person_text . '</option>';
        }
        echo '</select>';
        echo '</div>';
        
        echo '<div class="pr-form-row">';
        echo '<label for="pr-requests">' . __('Special Requests', 'power-reservations') . '</label>';
        echo '<textarea id="pr-requests" name="special_requests" rows="3"></textarea>';
        echo '</div>';
        
        echo '<div class="pr-form-row">';
        echo '<button type="submit" class="pr-submit-btn">' . __('Make Reservation', 'power-reservations') . '</button>';
        echo '</div>';
        
        echo '<div id="pr-message" class="pr-message" style="display: none;"></div>';
        echo '</form>';
        echo '</div>';
    }
    
    /**
     * Handle reservation submission
     */
    public function handle_reservation_submission() {
        if (!wp_verify_nonce($_POST['pr_nonce'], 'pr_nonce')) {
            wp_send_json_error(__('Security check failed.', 'power-reservations'));
        }
        
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $phone = sanitize_text_field($_POST['phone']);
        $date = sanitize_text_field($_POST['date']);
        $time = sanitize_text_field($_POST['time']);
        $party_size = intval($_POST['party_size']);
        $special_requests = sanitize_textarea_field($_POST['special_requests']);
        
        if (empty($name) || empty($email) || empty($date) || empty($time) || empty($party_size)) {
            wp_send_json_error(__('Please fill in all required fields.', 'power-reservations'));
        }
        
        if (!is_email($email)) {
            wp_send_json_error(__('Please enter a valid email address.', 'power-reservations'));
        }
        
        // Check availability
        global $wpdb;
        $table_name = $wpdb->prefix . 'pr_reservations';
        $max_per_slot = get_option('pr_max_reservations_per_slot', 5);
        
        $existing_count = $wpdb->get_var($wpdb->prepare(
            "SELECT SUM(party_size) FROM $table_name WHERE reservation_date = %s AND reservation_time = %s AND status IN ('pending', 'approved')",
            $date, $time
        ));
        
        if (($existing_count + $party_size) > $max_per_slot) {
            wp_send_json_error(__('Sorry, that time slot is no longer available.', 'power-reservations'));
        }
        
        // Generate unique reservation ID and edit token
        $reservation_id = strtoupper(wp_generate_password(8, false));
        $edit_token = wp_generate_password(32, false);
        
        // Get user ID if logged in
        $user_id = is_user_logged_in() ? get_current_user_id() : null;
        
        $result = $wpdb->insert(
            $table_name,
            array(
                'reservation_id' => $reservation_id,
                'user_id' => $user_id,
                'name' => $name,
                'email' => $email,
                'phone' => $phone,
                'reservation_date' => $date,
                'reservation_time' => $time,
                'party_size' => $party_size,
                'special_requests' => $special_requests,
                'status' => get_option('pr_require_approval', false) ? 'pending' : 'approved',
                'edit_token' => $edit_token
            ),
            array('%s', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s')
        );
        
        if ($result === false) {
            wp_send_json_error(__('Error saving reservation. Please try again.', 'power-reservations'));
        }
        
        $reservation_db_id = $wpdb->insert_id;
        
        // Send confirmation email to customer
        $this->send_confirmation_email($reservation_db_id);
        
        // Send notification email to admin
        $this->send_admin_notification_email($reservation_db_id);
        
        // Schedule reminder email for the day of reservation
        $reminder_time = strtotime($date . ' 08:00:00'); // 8 AM on reservation day
        if ($reminder_time > time()) {
            wp_schedule_single_event($reminder_time, 'pr_send_reminder', array($reservation_db_id));
        }
        
        wp_send_json_success(array(
            'message' => __('Reservation submitted successfully!', 'power-reservations'),
            'reservation_id' => $reservation_id,
            'edit_link' => home_url('?pr_action=edit&token=' . $edit_token)
        ));
    }
    
    /**
     * Send confirmation email to customer
     */
    private function send_confirmation_email($reservation_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'pr_reservations';
        $templates_table = $wpdb->prefix . 'pr_email_templates';
        
        $reservation = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $reservation_id));
        if (!$reservation) return;
        
        $template = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $templates_table WHERE template_name = %s AND is_active = 1",
            'confirmation'
        ));
        
        if (!$template) return;
        
        $edit_link = home_url('?pr_action=edit&token=' . $reservation->edit_token);
        
        $placeholders = array(
            '{name}' => $reservation->name,
            '{email}' => $reservation->email,
            '{phone}' => $reservation->phone,
            '{date}' => date('F j, Y', strtotime($reservation->reservation_date)),
            '{time}' => date('g:i A', strtotime($reservation->reservation_time)),
            '{party_size}' => $reservation->party_size,
            '{special_requests}' => $reservation->special_requests,
            '{business_name}' => get_option('pr_business_name', get_bloginfo('name')),
            '{reservation_id}' => $reservation->reservation_id,
            '{edit_link}' => $edit_link
        );
        
        $subject = str_replace(array_keys($placeholders), array_values($placeholders), $template->template_subject);
        $message = str_replace(array_keys($placeholders), array_values($placeholders), $template->template_content);
        
        wp_mail($reservation->email, $subject, $message, array('Content-Type: text/html; charset=UTF-8'));
    }
    
    /**
     * Send notification email to admin
     */
    private function send_admin_notification_email($reservation_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'pr_reservations';
        $templates_table = $wpdb->prefix . 'pr_email_templates';
        
        $reservation = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $reservation_id));
        if (!$reservation) return;
        
        $template = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $templates_table WHERE template_name = %s AND is_active = 1",
            'admin_notification'
        ));
        
        if (!$template) return;
        
        $admin_link = admin_url('admin.php?page=power-reservations&action=view&reservation=' . $reservation->id);
        
        $placeholders = array(
            '{name}' => $reservation->name,
            '{email}' => $reservation->email,
            '{phone}' => $reservation->phone,
            '{date}' => date('F j, Y', strtotime($reservation->reservation_date)),
            '{time}' => date('g:i A', strtotime($reservation->reservation_time)),
            '{party_size}' => $reservation->party_size,
            '{special_requests}' => $reservation->special_requests,
            '{business_name}' => get_option('pr_business_name', get_bloginfo('name')),
            '{reservation_id}' => $reservation->reservation_id,
            '{admin_link}' => $admin_link
        );
        
        $subject = str_replace(array_keys($placeholders), array_values($placeholders), $template->template_subject);
        $message = str_replace(array_keys($placeholders), array_values($placeholders), $template->template_content);
        
        $admin_email = get_option('pr_business_email', get_option('admin_email'));
        wp_mail($admin_email, $subject, $message, array('Content-Type: text/html; charset=UTF-8'));
    }
    
    /**
     * Send notification email
     */
    private function send_notification_email($name, $email, $date, $time, $party_size) {
        $business_email = get_option('pr_business_email', get_option('admin_email'));
        $business_name = get_option('pr_business_name', get_bloginfo('name'));
        
        $subject = sprintf(__('New Reservation Request - %s', 'power-reservations'), $business_name);
        $message = sprintf(
            __("New reservation request:\n\nName: %s\nEmail: %s\nDate: %s\nTime: %s\nParty Size: %s", 'power-reservations'),
            $name, $email, $date, $time, $party_size
        );
        
        if (function_exists('wp_mail')) {
            wp_mail($business_email, $subject, $message);
        }
    }
    
    /**
     * My Reservations shortcode
     */
    public function my_reservations_shortcode($atts) {
        if (!is_user_logged_in()) {
            return '<p>' . __('Please log in to view your reservations.', 'power-reservations') . '</p>';
        }
        
        $user_id = get_current_user_id();
        global $wpdb;
        $table_name = $wpdb->prefix . 'pr_reservations';
        
        $reservations = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name WHERE user_id = %d ORDER BY reservation_date DESC, reservation_time DESC",
            $user_id
        ));
        
        if (empty($reservations)) {
            return '<p>' . __('You have no reservations yet.', 'power-reservations') . '</p>';
        }
        
        ob_start();
        echo '<div class="pr-my-reservations">';
        echo '<h3>' . __('My Reservations', 'power-reservations') . '</h3>';
        
        foreach ($reservations as $reservation) {
            $can_edit = strtotime($reservation->reservation_date . ' ' . $reservation->reservation_time) > (time() + (get_option('pr_edit_window_hours', 24) * 3600));
            
            echo '<div class="pr-reservation-item status-' . esc_attr($reservation->status) . '">';
            echo '<div class="pr-reservation-header">';
            echo '<h4>' . sprintf(__('Reservation #%s', 'power-reservations'), esc_html($reservation->reservation_id)) . '</h4>';
            echo '<span class="pr-reservation-status">' . esc_html(ucfirst($reservation->status)) . '</span>';
            echo '</div>';
            
            echo '<div class="pr-reservation-details">';
            echo '<p><strong>' . __('Date:', 'power-reservations') . '</strong> ' . esc_html(date('F j, Y', strtotime($reservation->reservation_date))) . '</p>';
            echo '<p><strong>' . __('Time:', 'power-reservations') . '</strong> ' . esc_html(date('g:i A', strtotime($reservation->reservation_time))) . '</p>';
            echo '<p><strong>' . __('Party Size:', 'power-reservations') . '</strong> ' . esc_html($reservation->party_size) . '</p>';
            if ($reservation->special_requests) {
                echo '<p><strong>' . __('Special Requests:', 'power-reservations') . '</strong> ' . esc_html($reservation->special_requests) . '</p>';
            }
            echo '</div>';
            
            if ($can_edit && in_array($reservation->status, array('pending', 'approved'))) {
                echo '<div class="pr-reservation-actions">';
                echo '<a href="?pr_action=edit&token=' . esc_attr($reservation->edit_token) . '" class="button">' . __('Edit', 'power-reservations') . '</a>';
                echo '<a href="?pr_action=cancel&token=' . esc_attr($reservation->edit_token) . '" class="button button-secondary" onclick="return confirm(\'' . __('Are you sure you want to cancel this reservation?', 'power-reservations') . '\')">' . __('Cancel', 'power-reservations') . '</a>';
                echo '</div>';
            }
            
            echo '</div>';
        }
        
        echo '</div>';
        return ob_get_clean();
    }
    
    /**
     * Check availability AJAX handler
     */
    public function check_availability() {
        check_ajax_referer('pr_nonce', 'nonce');
        
        $date = sanitize_text_field($_POST['date']);
        $party_size = intval($_POST['party_size']);
        
        if (empty($date) || empty($party_size)) {
            wp_send_json_error(__('Invalid parameters.', 'power-reservations'));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'pr_reservations';
        $max_per_slot = get_option('pr_max_reservations_per_slot', 5);
        $time_slots = get_option('pr_time_slots', array());
        
        $available_times = array();
        
        foreach ($time_slots as $time => $label) {
            $existing_count = $wpdb->get_var($wpdb->prepare(
                "SELECT SUM(party_size) FROM $table_name WHERE reservation_date = %s AND reservation_time = %s AND status IN ('pending', 'approved')",
                $date, $time
            ));
            
            $remaining_capacity = $max_per_slot - intval($existing_count);
            
            if ($remaining_capacity >= $party_size) {
                $available_times[] = array(
                    'value' => $time,
                    'label' => $label,
                    'remaining' => $remaining_capacity
                );
            }
        }
        
        wp_send_json_success($available_times);
    }
    
    /**
     * Handle reservation cancellation
     */
    public function handle_reservation_cancellation() {
        check_ajax_referer('pr_nonce', 'nonce');
        
        $token = sanitize_text_field($_POST['token']);
        
        if (empty($token)) {
            wp_send_json_error(__('Invalid token.', 'power-reservations'));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'pr_reservations';
        
        $reservation = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE edit_token = %s",
            $token
        ));
        
        if (!$reservation) {
            wp_send_json_error(__('Reservation not found.', 'power-reservations'));
        }
        
        // Check if within edit window
        $edit_window_hours = get_option('pr_edit_window_hours', 24);
        $reservation_time = strtotime($reservation->reservation_date . ' ' . $reservation->reservation_time);
        
        if ($reservation_time <= (time() + ($edit_window_hours * 3600))) {
            wp_send_json_error(__('Cannot cancel reservation within the edit window.', 'power-reservations'));
        }
        
        $wpdb->update(
            $table_name,
            array('status' => 'cancelled'),
            array('id' => $reservation->id),
            array('%s'),
            array('%d')
        );
        
        wp_send_json_success(__('Reservation cancelled successfully.', 'power-reservations'));
    }
    
    /**
     * Handle reservation edit
     */
    public function handle_reservation_edit() {
        check_ajax_referer('pr_nonce', 'nonce');
        
        $token = sanitize_text_field($_POST['token']);
        
        if (empty($token)) {
            wp_send_json_error(__('Invalid token.', 'power-reservations'));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'pr_reservations';
        
        $reservation = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE edit_token = %s",
            $token
        ));
        
        if (!$reservation) {
            wp_send_json_error(__('Reservation not found.', 'power-reservations'));
        }
        
        // Check if within edit window
        $edit_window_hours = get_option('pr_edit_window_hours', 24);
        $reservation_time = strtotime($reservation->reservation_date . ' ' . $reservation->reservation_time);
        
        if ($reservation_time <= (time() + ($edit_window_hours * 3600))) {
            wp_send_json_error(__('Cannot edit reservation within the edit window.', 'power-reservations'));
        }
        
        // Update reservation
        $wpdb->update(
            $table_name,
            array(
                'reservation_date' => sanitize_text_field($_POST['date']),
                'reservation_time' => sanitize_text_field($_POST['time']),
                'party_size' => intval($_POST['party_size']),
                'special_requests' => sanitize_textarea_field($_POST['special_requests'])
            ),
            array('id' => $reservation->id),
            array('%s', '%s', '%d', '%s'),
            array('%d')
        );
        
        wp_send_json_success(__('Reservation updated successfully.', 'power-reservations'));
    }
    
    /**
     * Add query vars for reservation management
     */
    public function add_query_vars($vars) {
        $vars[] = 'pr_action';
        $vars[] = 'token';
        return $vars;
    }
    
    /**
     * Handle reservation actions from URL
     */
    public function handle_reservation_actions() {
        $action = get_query_var('pr_action');
        $token = get_query_var('token');
        
        if (!$action || !$token) {
            return;
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'pr_reservations';
        
        $reservation = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE edit_token = %s",
            $token
        ));
        
        if (!$reservation) {
            wp_die(__('Invalid reservation link.', 'power-reservations'));
        }
        
        if ($action === 'cancel') {
            $wpdb->update(
                $table_name,
                array('status' => 'cancelled'),
                array('id' => $reservation->id),
                array('%s'),
                array('%d')
            );
            
            wp_redirect(add_query_arg('pr_message', 'cancelled', remove_query_arg(array('pr_action', 'token'))));
            exit;
        }
    }
    
    /**
     * Send reminder email
     */
    public function send_reminder_email($reservation_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'pr_reservations';
        
        $reservation = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE id = %d AND reminder_sent = 0",
            $reservation_id
        ));
        
        if (!$reservation) {
            return;
        }
        
        // Use email template
        $templates_table = $wpdb->prefix . 'pr_email_templates';
        $template = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $templates_table WHERE template_name = %s AND is_active = 1",
            'reminder'
        ));
        
        if ($template) {
            $placeholders = array(
                '{name}' => $reservation->name,
                '{date}' => date('F j, Y', strtotime($reservation->reservation_date)),
                '{time}' => date('g:i A', strtotime($reservation->reservation_time)),
                '{party_size}' => $reservation->party_size,
                '{business_name}' => get_option('pr_business_name', get_bloginfo('name'))
            );
            
            $subject = str_replace(array_keys($placeholders), array_values($placeholders), $template->template_subject);
            $message = str_replace(array_keys($placeholders), array_values($placeholders), $template->template_content);
            
            if (wp_mail($reservation->email, $subject, $message, array('Content-Type: text/html; charset=UTF-8'))) {
                $wpdb->update(
                    $table_name,
                    array('reminder_sent' => 1),
                    array('id' => $reservation_id),
                    array('%d'),
                    array('%d')
                );
            }
        }
    }
    
    /**
     * Daily cleanup
     */
    public function daily_cleanup() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'pr_reservations';
        
        // Schedule reminder emails for today's reservations
        $today = date('Y-m-d');
        $reservations = $wpdb->get_results($wpdb->prepare(
            "SELECT id FROM $table_name WHERE reservation_date = %s AND status = 'approved' AND reminder_sent = 0",
            $today
        ));
        
        foreach ($reservations as $reservation) {
            wp_schedule_single_event(time(), 'pr_send_reminder', array($reservation->id));
        }
        
        // Clean up old cancelled reservations (older than 30 days)
        $wpdb->delete(
            $table_name,
            array(
                'status' => 'cancelled',
            ),
            array('%s'),
            'created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)'
        );
    }
    
    /**
     * Add dashboard widget
     */
    public function add_dashboard_widget() {
        wp_add_dashboard_widget(
            'pr_dashboard_widget',
            __('Reservation Summary', 'power-reservations'),
            array($this, 'dashboard_widget_content')
        );
    }
    
    /**
     * Dashboard widget content
     */
    public function dashboard_widget_content() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'pr_reservations';
        $today = date('Y-m-d');
        
        $stats = array(
            'today' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE reservation_date = %s", $today)),
            'pending' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE status = %s", 'pending')),
            'this_week' => $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE reservation_date BETWEEN %s AND %s", $today, date('Y-m-d', strtotime('+7 days'))))
        );
        
        echo '<div class="pr-dashboard-stats">';
        echo '<p><strong>' . $stats['today'] . '</strong> ' . __('reservations today', 'power-reservations') . '</p>';
        echo '<p><strong>' . $stats['pending'] . '</strong> ' . __('pending approval', 'power-reservations') . '</p>';
        echo '<p><strong>' . $stats['this_week'] . '</strong> ' . __('reservations this week', 'power-reservations') . '</p>';
        echo '<p><a href="' . admin_url('admin.php?page=power-reservations') . '" class="button">' . __('Manage Reservations', 'power-reservations') . '</a></p>';
        echo '</div>';
    }
    
    /**
     * Admin init
     */
    public function admin_init() {
        // Register settings
        register_setting('pr_settings', 'pr_business_name');
        register_setting('pr_settings', 'pr_business_email');
        register_setting('pr_settings', 'pr_max_party_size');
        register_setting('pr_settings', 'pr_booking_window');
        register_setting('pr_settings', 'pr_max_reservations_per_slot');
        register_setting('pr_settings', 'pr_edit_window_hours');
        register_setting('pr_settings', 'pr_require_approval');
        register_setting('pr_settings', 'pr_blackout_dates');
        register_setting('pr_settings', 'pr_opening_hours');
        register_setting('pr_settings', 'pr_time_slot_duration');
    }
}

/**
 * Initialize the plugin
 */
function power_reservations_init() {
    return PowerReservations::get_instance();
}
add_action('plugins_loaded', 'power_reservations_init');

/**
 * Uninstall hook
 */
register_uninstall_hook(__FILE__, 'power_reservations_uninstall');

function power_reservations_uninstall() {
    global $wpdb;
    
    // Drop all plugin tables
    $tables = array(
        $wpdb->prefix . 'pr_reservations',
        $wpdb->prefix . 'pr_settings', 
        $wpdb->prefix . 'pr_email_templates'
    );
    
    foreach ($tables as $table) {
        $wpdb->query("DROP TABLE IF EXISTS $table");
    }
    
    // Delete all plugin options
    $options = array(
        'pr_db_version',
        'pr_business_name',
        'pr_business_email', 
        'pr_max_party_size',
        'pr_booking_window',
        'pr_max_reservations_per_slot',
        'pr_edit_window_hours',
        'pr_require_approval',
        'pr_blackout_dates',
        'pr_opening_hours',
        'pr_time_slot_duration',
        'pr_time_slots'
    );
    
    foreach ($options as $option) {
        delete_option($option);
    }
    
    // Clear scheduled events
    wp_clear_scheduled_hook('pr_daily_cleanup');
    wp_clear_scheduled_hook('pr_send_reminder');
}
