<?php
/**
 * Power Reservations Uninstall Handler
 * 
 * This file is executed when the plugin is uninstalled (deleted) from WordPress.
 * It completely removes all plugin data from the database.
 * 
 * IMPORTANT: This only runs when the plugin is DELETED, not deactivated.
 * 
 * @package PowerReservations
 * @version 2.0.0
 */

// Security check - only run if called by WordPress uninstall process
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

/* ========================================
   DATABASE CLEANUP
   ======================================== */

// Get WordPress database connection
global $wpdb;

// Remove the reservations table
$table_name = $wpdb->prefix . 'pr_reservations';
$wpdb->query("DROP TABLE IF EXISTS $table_name");

/* ========================================
   OPTIONS CLEANUP
   ======================================== */

// Remove all plugin options from wp_options table
delete_option('pr_db_version');        // Database version
delete_option('pr_business_name');     // Business name setting
delete_option('pr_business_email');    // Business email setting
delete_option('pr_max_party_size');    // Maximum party size setting
delete_option('pr_booking_window');    // Booking window (days) setting
delete_option('pr_time_slots');        // Available time slots setting